package com.github.romankh3.springbatchexample.model;

import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "user")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class EmailDomainCas {

    @Id
    private Long id;
    private String casId;
    private String domain;
    private Date time;
}

package com.github.romankh3.springbatchexample.batch;

import com.github.romankh3.springbatchexample.model.EmailDomainCas;
import com.github.romankh3.springbatchexample.repository.DomainCasIdRepository;
import java.util.List;
import java.util.logging.Logger;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class UserWriter implements ItemWriter<EmailDomainCas> {

    private static final Logger LOGGER = Logger.getLogger(UserWriter.class.getName());

    @Autowired
    private DomainCasIdRepository domainCasIdRepository;

    @Override
    public void write(List<? extends EmailDomainCas> users) throws Exception {
        LOGGER.info("Data saved for users: " + users);
        users.forEach(domainCasIdRepository::save);
    }
}

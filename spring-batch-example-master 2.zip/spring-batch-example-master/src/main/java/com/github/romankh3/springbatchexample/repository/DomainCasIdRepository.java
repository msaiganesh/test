package com.github.romankh3.springbatchexample.repository;

import com.github.romankh3.springbatchexample.model.EmailDomainCas;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DomainCasIdRepository extends JpaRepository<EmailDomainCas, Long> {
}

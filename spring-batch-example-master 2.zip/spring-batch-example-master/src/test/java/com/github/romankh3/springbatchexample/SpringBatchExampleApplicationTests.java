package com.github.romankh3.springbatchexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBatchExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
